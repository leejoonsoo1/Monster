﻿//------------------------------------------------------------
// Game Framework - MIT License
// Copyright © 2013–2021 Jiang Yin (EllanJiang)
// Modified © 2025 얌얌코딩
// Homepage: https://www.yamyamcoding.com/
// Feedback: mailto:eazuooz@gmail.com
//------------------------------------------------------------

namespace GameFramework.Sound
{
    public interface ISoundGroup
    {
        string Name
        {
            get;
        }

        int SoundAgentCount
        {
            get;
        }

        bool AvoidBeingReplacedBySamePriority
        {
            get;
            set;
        }

        bool Mute
        {
            get;
            set;
        }

        float Volume
        {
            get;
            set;
        }

        ISoundGroupHelper Helper
        {
            get;
        }

        void StopAllLoadedSounds();

        void StopAllLoadedSounds(float fadeOutSeconds);
    }
}
