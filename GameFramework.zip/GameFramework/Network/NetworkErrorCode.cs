﻿//------------------------------------------------------------
// Game Framework - MIT License
// Copyright © 2013–2021 Jiang Yin (EllanJiang)
// Modified © 2025 얌얌코딩
// Homepage: https://www.yamyamcoding.com/
// Feedback: mailto:eazuooz@gmail.com
//------------------------------------------------------------

namespace GameFramework.Network
{
    public enum NetworkErrorCode : byte
    {
        Unknown = 0,

        AddressFamilyError,

        SocketError,

        ConnectError,

        SendError,

        ReceiveError,

        SerializeError,

        DeserializePacketHeaderError,

        DeserializePacketError
    }
}
