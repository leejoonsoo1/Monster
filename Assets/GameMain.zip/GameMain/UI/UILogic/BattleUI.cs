using System;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using UnityGameFramework.Runtime;

namespace Monster
{
    public class BattleUI : UIFormLogic
    {
        private const float mWidth = 1440f;
        private const float mHeight = 1080f;

        [SerializeField] private Transform mEnemyStatusRoot;
        [SerializeField] private Transform mPlayerStatusRoot;
        [SerializeField] private Transform mBottomRoot;
        // FightMenu 변수 선언
        [SerializeField] private Transform mFightMenu;

        [SerializeField] private RectTransform mEnemyStatus1;
        [SerializeField] private RectTransform mEnemyStatus2;
        [SerializeField] private RectTransform mPlayerStatus1;
        [SerializeField] private RectTransform mPlayerStatus2;

        [SerializeField] private Sprite mFightNormalSprite;
        [SerializeField] private Sprite mBagNormalSprite;
        [SerializeField] private Sprite mPokemonNormalSprite;
        [SerializeField] private Sprite mRunNormalSprite;

        [SerializeField] private Sprite mFightSelectedSprite;
        [SerializeField] private Sprite mBagSelectedSprite;
        [SerializeField] private Sprite mPokemonSelectedSprite;
        [SerializeField] private Sprite mRunSelectedSprite;

        // 버튼 상태를 BattleUI에서 직접 관리합니다.
        private Image[] mButtonImages;
        private Sprite[] mNormalSprites;
        private Sprite[] mSelectedSprites;

        private MyProcedureBattle mBattleProcedure;

        private int mSelectedIndex      = 0;
        private bool mIsFightMenuOpen   = false;

        protected internal override void OnOpen(object userData)
        {
            base.OnOpen(userData);

            Log.Info("BattleUI : Open");

            RectTransform rootRect = transform as RectTransform;

            if (rootRect != null)
            {
                rootRect.anchorMin = new Vector2(0.5f, 1f);
                rootRect.anchorMax = new Vector2(0.5f, 1f);
                rootRect.pivot = new Vector2(0.5f, 1f);
                rootRect.anchoredPosition = Vector2.zero;
                rootRect.sizeDelta = new Vector2(mWidth, mHeight);
                rootRect.localScale = Vector3.one;
            }
            else
            {
                RectTransform parentRect = transform.parent as RectTransform;

                if (parentRect != null)
                {
                    float centerX = (0.5f - parentRect.pivot.x) * parentRect.rect.width;
                    float topY = (1f - parentRect.pivot.y) * parentRect.rect.height;
                    transform.localPosition = new Vector3(centerX, topY, 0f);
                }
                else
                {
                    Log.Warning("BattleUI : 부모 RectTransform을 찾지 못했습니다.");
                }

                transform.localScale = Vector3.one;
            }

            SetUIRect(mEnemyStatusRoot, new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(0f, -80f), new Vector2(600f, 160f), new Vector2(-mWidth * 0.5f, -80f));
            SetUIRect(mPlayerStatusRoot, new Vector2(1f, 0f), new Vector2(1f, 0f), new Vector2(0f, 300f), new Vector2(600f, 180f), new Vector2(mWidth * 0.5f, -mHeight + 300f));
            SetUIRect(mBottomRoot, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0f, -810f), new Vector2(1440f, 270f), new Vector2(0f, -810f));

            // FightMenu SetUIRect() 호출합니다.
            if (mFightMenu == null)
            {
                mFightMenu = transform.Find("FIghtMenu");
                if (mFightMenu == null)
                {
                    mFightMenu = transform.Find("FightMenu");
                }
            }

            SetUIRect(mFightMenu, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0f, -810f), new Vector2(1440f, 270f), new Vector2(0f, -810f));
            SetFightMenuVisible(false);

            // 상대 체력바를 왼쪽 상단 영역의 가운데에 배치합니다.
            SetUIRect(mEnemyStatus1, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(400f, 120f), new Vector2(300f, -80f));

            // 아군 체력바를 오른쪽 하단 영역의 가운데에 배치합니다.
            SetUIRect(mPlayerStatus1, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(400f, 120f), new Vector2(-300f, 90f));

            SetUIVisible(mEnemyStatus1, true);
            //SetStatusVisible(mEnemyStatus2,     false);
            SetUIVisible(mPlayerStatus1, true);
            //SetStatusVisible(mPlayerStatus2,    false);

            // Inspector 연결 없이 부모 Root에서 2번 상태창을 찾습니다.
            Transform enemyStatus2 = mEnemyStatus2;
            Transform playerStatus2 = mPlayerStatus2;

            if (enemyStatus2 == null && mEnemyStatusRoot != null)
            {
                enemyStatus2 = mEnemyStatusRoot.Find("EnemyStatus2");
            }

            if (playerStatus2 == null && mPlayerStatusRoot != null)
            {
                playerStatus2 = mPlayerStatusRoot.Find("PlayerStatus2");
            }

            // 싱글 배틀에서는 2번 상태창을 비활성화합니다.
            SetUIVisible(enemyStatus2, false);
            SetUIVisible(playerStatus2, false);


            // 하단 버튼의 기본 Sprite와 선택 Sprite를 초기화합니다.
            InitializeButtons();

            // BattleProcedure를 가져옵니다.
            mBattleProcedure = GameEntry.GetComponent<ProcedureComponent>().CurrentProcedure as MyProcedureBattle;

            if (mBattleProcedure == null)
            {
                Log.Error("BattleUI : ProcedureComponent가 없습니다.");
            }

            Log.Info("BattleUI : Single Battle UI 활성화 완료");
        }

        // BattleBottomUI의 방향키 입력 처리를 통합합니다.
        protected internal override void OnUpdate(float elapseSeconds, float realElapseSeconds)
        {
            base.OnUpdate(elapseSeconds, realElapseSeconds);

            if (mButtonImages == null)
            {
                return;
            }

            // FightMenu가 열려있으면 방향키 입력을 무시합니다.
            if (mIsFightMenuOpen == true)
            {
                UpdateFightMenu();

                // 기존 CommandMenu의 입별 처리는 실행하지 않습니다.
                return;
            }

            // FightMenu가 닫혀 있으면 기존 명령 메뉴를 처리합니다.
            UpdateCommandMenu();
        }

        // FightMenu의 입력을 처리합니다.
        private void UpdateFightMenu()
        {
            // X키를 누르면 기술 선택 메뉴를 딛고 기본 명령 메뉴로 돌아갑니다.
            if (Input.GetKeyDown(KeyCode.X) == true)
            {
                SetFightMenuVisible(false);

                return;
            }

            // 기술 선택 방향키와 C키 확정은 이 함수에서 구현합니다.
        }

        // 싸운다, 가방, 포켓몬, 도망의 입력을 처리합니다.
        private void UpdateCommandMenu()
        {
            // 기본 메뉴에서는 X키를 눌러도 별도 동작을 하지 않습니다.
            if (Input.GetKeyDown(KeyCode.X) == true)
            {
                return;
            }

            // C키로 현재 선택된 명령을 실행합니다.
            if (Input.GetKeyDown(KeyCode.C) == true)
            {
                // 싸운다 버튼 선택 시 기술 메뉴를 표시합니다.
                if (mSelectedIndex == 0)
                {
                    SetFightMenuVisible(true);
                }
                // 도망 버튼 선택 시 전투 종료 함수를 호출합니다.
                else if (mSelectedIndex == 1)
                {
                    ;
                }
                else if (mSelectedIndex == 2)
                {
                    ;
                }
                else if (mSelectedIndex == 3)
                {
                    // Procedure 참조가 있을 때만 종료를 요청합니다.
                    if (mBattleProcedure != null)
                    {
                        mBattleProcedure.FinishBattle();
                    }
                    else
                    {
                        Log.Warning("BattleUI : MyProcedureBattle을 찾을 수 없습니다.");
                    }
                }

                return;
            }

            // 방향키 입련에 따라 다음 선택 인덱스를 계산합니다.
            int nextIndex = mSelectedIndex;

            if (Input.GetKeyDown(KeyCode.LeftArrow) == true)
            {
                if (nextIndex % 2 == 1)
                {
                    nextIndex--;
                }
            }
            else if (Input.GetKeyDown(KeyCode.RightArrow) == true)
            {
                if (nextIndex % 2 == 0)
                {
                    nextIndex++;
                }
            }
            else if (Input.GetKeyDown(KeyCode.UpArrow) == true)
            {
                if (nextIndex >= 2)
                {
                    nextIndex -= 2;
                }
            }
            else if (Input.GetKeyDown(KeyCode.DownArrow) == true)
            {
                if (nextIndex < 2)
                {
                    nextIndex += 2;
                }
            }

            // 선택된 버튼이 변경되지 않았다면 종료합니다.
            if (nextIndex == mSelectedIndex)
            {
                return;
            }

            // 변경 전 버튼의 인덱스를 저장합니다.
            int previousIndex = mSelectedIndex;

            // 새로운 버튼의 인덱스를 저장합니다.
            mSelectedIndex = nextIndex;

            // 이전 버튼을 일반 Sprite로 복원합니다.
            SetButtonSprite(previousIndex, false);

            // 새로운 버튼을 선택 Sprite로 변경합니다.
            SetButtonSprite(mSelectedIndex, true);

            Log.Info($"BattleUI : Selected Index = {mSelectedIndex}");
        }

        private void SetFightMenuVisible(bool isVisible)
        {
            // FightMenu를 열려고 하지만 오브젝트가 없다면 중단합니다.
            if (isVisible == true && mFightMenu == null)
            {
                Log.Warning("BattleUI : FightMenu를 찾을 수 없습니다.");

                return;
            }

            // 현재 FightMenu의 활성화 상태를 저장합니다.
            mIsFightMenuOpen = isVisible;

            // FightMenu의 활성화 상태를 변경합니다.
            SetUIVisible(mFightMenu, isVisible);

            // FightMenu가 표시되면 기존 BottomUI는 숨깁니다.
            SetUIVisible(mBottomRoot, isVisible == false);
        }

        // BottomUI 자식 네 개를 버튼 순서대로 연결합니다.
        private void InitializeButtons()
        {
            mButtonImages = null;
            mNormalSprites = null;
            mSelectedSprites = null;

            // BottomUI가 연결되지 않았거나 자식 버튼이 4개 미만이면 초기화를 중단합니다.
            if (mBottomRoot == null || mBottomRoot.childCount < 4)
            {
                Log.Error("BattleUI : BottomUI 또는 버튼 4개를 찾을 수 없습니다.");

                return;
            }

            float buttonWidth = 340f;
            float buttonHeight = 120f;

            Vector2[] positions =
            {
                new Vector2(170f, 65f),
                new Vector2(530f, 65f),
                new Vector2(170f, -65f),
                new Vector2(530f, -65f)
            };

            // 각 버튼의 Image 컴포넌트를 저장할 배열입니다.
            Image[] buttonImages = new Image[4];

            // Hierarchy에 등록된 버튼 GameObject의 이름입니다.
            // 버튼을 자식 인덱스가 아닌 이름으로 탐색할 때 사용합니다.
            string[] buttonNames =
            {
                "FightButton",
                "BagButton",
                "PokemonButton",
                "RunButton"
            };

            // 선택되지 않은 버튼에 사용할 일반 Sprite입니다.
            // Inspector에 연결한 Sprite를 배열에 저장합니다.
            Sprite[] normalSprites =
            {
                mFightNormalSprite,
                mBagNormalSprite,
                mPokemonNormalSprite,
                mRunNormalSprite
            };

            // 현재 선택된 버튼에 사용할 Sprite입니다.
            // Inspector에 연결한 선택 Sprite를 배열에 저장합니다.
            Sprite[] selectedSprites =
            {
                mFightSelectedSprite,
                mBagSelectedSprite,
                mPokemonSelectedSprite,
                mRunSelectedSprite
            };

            // 4개의 버튼을 순서대로 탐색하고 초기화합니다.
            for (int Index = 0; Index < positions.Length; Index++)
            {
                // BottomUI의 자식 중 이름이 일치하는 버튼을 탐색합니다.
                Transform buttonTransform = mBottomRoot.Find(buttonNames[Index]);

                // 버튼의 UI 위치와 크기를 제어하기 위해 RectTransform으로 변환합니다.
                RectTransform buttonRect = buttonTransform as RectTransform;

                // 버튼이 없거나 RectTransform을 가지고 있지 않으면 종료합니다.
                if (buttonRect == null)
                {
                    Log.Error($"BattleUI : {buttonNames[Index]}을 찾을 수 없습니다.");

                    return;
                }

                // 버튼의 Anchor를 부모 BottomUI의 중앙으로 고정합니다.
                buttonRect.anchorMin = new Vector2(0.5f, 0.5f);
                buttonRect.anchorMax = new Vector2(0.5f, 0.5f);

                // 버튼 자체의 기준점을 중앙으로 설정합니다.
                buttonRect.pivot = new Vector2(0.5f, 0.5f);

                buttonRect.anchoredPosition = positions[Index];
                buttonRect.sizeDelta = new Vector2(buttonWidth, buttonHeight);

                buttonRect.localScale = Vector3.one;

                Image buttonImage = buttonRect.GetComponent<Image>();

                if (buttonImage == null)
                {
                    Log.Error($"BattleUI : {buttonNames[Index]}에 Image가 없습니다.");

                    return;
                }

                // 버튼에 Unity UI Button 컴포턴트가 있는지 확인합니다.
                Button button = buttonRect.GetComponent<Button>();

                if (button != null)
                {
                    // Unity Button의 기본 색상 및 Sprite 전환을 비활성화합니다.
                    // Sprite 변경은 BattleUI의 SetButtonSprite()에서 직접 처리합니다.
                    button.transition = Selectable.Transition.None;
                }

                // Image의 색상을 흰색으로 설정하여 Sprite 원본 색상을 유지합니다.
                buttonImage.color = Color.white;

                // 현재 버튼의 Image 컴포넌틀르 배열에 저장합니다.
                buttonImages[Index] = buttonImage;

                // Inpector에 일반 Sprite가 연결되지 않은 경우입니다.
                if (normalSprites[Index] == null)
                {
                    // 현재 Image 컴포넌트에 설정된 Source Image를 일반 Sprite로 사용합니다.
                    normalSprites[Index] = buttonImage.sprite;

                    // 일반 Sprite가 연결되지 않았음을 경고합니다.
                    Log.Warning($"BattleUI:{buttonNames[Index]} 일반 Sprite 미연결." +
                        $"현재 Source Image를 사용합니다.");
                }

                // 복원할 기본 이미지조차 없다면 오류를 출력합니다.
                if (normalSprites[Index] == null)
                {
                    // 선택 Sprite가 없더라도 일반 Sprite를 사용할 수 있으므로 경고만 출력합니다.
                    Log.Error($"BattleUI : {buttonNames[Index]}에 Sprite가 없습니다.");
                }

                // 선택 상태에 사용할 Sprite가 연결되어 있는지 확인합니다.
                if (selectedSprites[Index] == null)
                {
                    Log.Warning($"BattleUI : {buttonNames[Index]} 선택 Sprite 미연결.");
                }
            }

            // 초기화한 Image와 Sprite 배열을 멤버 변수에 저장합니다.
            // 이후 OnUpdate()와 SetButtonSprite()에서 사용합니다.
            mButtonImages = buttonImages;
            mNormalSprites = normalSprites;
            mSelectedSprites = selectedSprites;
            mSelectedIndex = 0;

            // 모든 버튼에 현재 선택 상태에 맞는 Sprite를 적용합니다.
            for (int index = 0; index < mButtonImages.Length; index++)
            {
                // 선택된 버튼은 선택 Sprite를 사용하고,
                // 선택되지 않은 버튼은 일반 Sprite를 사용합니다.
                SetButtonSprite(index, index == mSelectedIndex);
            }

            // 버튼 4개의 초기화가 정상적으로 완료되었음을 출력합니다.
            Log.Info("BattleUI : 버튼 초기화 완료");
        }

        // 지정한 버튼 하나의 Sprite만 변경합니다.
        private void SetButtonSprite(int index, bool isSelected)
        {
            if (mButtonImages == null ||
                mNormalSprites == null ||
                mSelectedSprites == null)
            {
                return;
            }

            if (index < 0 || index >= mButtonImages.Length)
            {
                return;
            }

            Image buttonImage = mButtonImages[index];

            if (buttonImage == null)
            {
                return;
            }

            Sprite targetSprite = mNormalSprites[index];

            if (isSelected == true &&
                mSelectedSprites[index] != null)
            {
                targetSprite = mSelectedSprites[index];
            }

            // Sprite가 실제로 다를 때만 교체합니다.
            if (buttonImage.sprite != targetSprite)
            {
                buttonImage.sprite = targetSprite;
            }

            // Sprite를 교체할 때 항상 원래 색상을 유지합니다.
            buttonImage.color = Color.white;
        }

        private void SetUIRect(Transform target, Vector2 anchor, Vector2 pivot, Vector2 anchoredPosition, Vector2 size, Vector2 localPosition)
        {
            if (target == null)
            {
                return;
            }

            RectTransform rect = target as RectTransform;
            RectTransform parentRect = target.parent as RectTransform;

            if (rect != null)
            {
                rect.pivot = pivot;
                rect.sizeDelta = size;

                if (parentRect != null)
                {
                    rect.anchorMin = anchor;
                    rect.anchorMax = anchor;
                    rect.anchoredPosition = anchoredPosition;
                }
                else
                {
                    rect.localPosition = new Vector3(localPosition.x, localPosition.y, 0f);
                }
            }
            else
            {
                // 일반 Transform에도 위치를 실제 적용합니다.
                target.localPosition = new Vector3(localPosition.x, localPosition.y, 0f);
            }

            // RectTransform과 Transform 모두 Scale을 초기화합니다.
            target.localScale = Vector3.one;
        }

        // UI를 활성화/비활성화합니다.
        private void SetUIVisible(Transform status, bool isVisible)
        {
            if (status == null)
            {
                return;
            }

            if (status.gameObject.activeSelf != isVisible)
            {
                status.gameObject.SetActive(isVisible);
            }
        }

        protected internal override void OnClose(bool isShutdown, object userData)
        {
            // 다음 배틀에서 기본 메뉴부터 열리도록 상태를 초기화합니다.
            SetFightMenuVisible(false);

            // BattleUI가 닫힐 때 버튼 Sprite를 기본 상태로 되돌립니다.
            if (mButtonImages != null && mNormalSprites != null)
            {
                for (int index = 0; index < mButtonImages.Length; index++)
                {
                    Image buttonImages = mButtonImages[index];

                    if (mButtonImages[index] != null)
                    {
                        buttonImages.sprite = mNormalSprites[index];
                        buttonImages.color = Color.white;
                    }
                }
            }

            mButtonImages = null;
            mNormalSprites = null;
            mSelectedSprites = null;

            mSelectedIndex = 0;

            Log.Info("BattleUI : Close");

            base.OnClose(isShutdown, userData);
        }

        // HP 게이지 Image 연결 전이므로 기존 빈 함수를 유지합니다.
        public void SetHP(int enemyCurrentHP, int enemyMaxHP, int playerCurrentHP, int playerMaxHP)
        {
        }
    }
}
