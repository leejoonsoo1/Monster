using Mono.Cecil.Cil;
using System.Runtime.CompilerServices;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;
using UnityGameFramework.Runtime;

namespace Monster
{
    public class BattleUI : UIFormLogic
    {
        // Battle UI의 크기입니다.
        private const float mWidth = 1440f;
        private const float mHeight = 1080f;

        // 각 UI의 부모 영역입니다.
        [SerializeField] private Transform mEnemyStatusRoot;
        [SerializeField] private Transform mPlayerStatusRoot;
        [SerializeField] private Transform mBottomRoot;

        // Find() 대신 Inspector에서 직접 연결합니다.
        [SerializeField] private RectTransform mEnemyStatus1;
        //[SerializeField] private RectTransform mEnemyStatus2;
        [SerializeField] private RectTransform mPlayerStatus1;
        //[SerializeField] private RectTransform mPlayerStatus2;

        // HP 게이지 이미지입니다.
        //[SerializeField] private Image mEnemyHPFill;
        //[SerializeField] private Image mPlayerHPFill;

        protected internal override void OnOpen(object userData)
        {
            base.OnOpen(userData);

            Log.Info("BattleUI : Open");

            RectTransform rootRect = transform as RectTransform;

           if (rootRect != null)
           {
                rootRect.anchorMin          = new Vector2(0.5f, 1f);
                rootRect.anchorMax          = new Vector2(0.5f, 1f);
                rootRect.pivot              = new Vector2(0.5f, 1f);
                rootRect.anchoredPosition   = Vector2.zero;
                rootRect.localScale     = Vector3.one;
           }
           else
           {
                // 일반 Transform을 부모 UI의 상단 중앙에 배치합니다.
                RectTransform parentRect = transform.parent as RectTransform;

                if (parentRect != null)
                {
                    float centerX   = (0.5f - parentRect.pivot.x) * parentRect.rect.width;
                    float topY      = (1f - parentRect.pivot.y) * parentRect.rect.height;

                    transform.localPosition = new Vector3(centerX, topY, 0f);
                }
                else
                {
                    Log.Warning("BattleUI : 부모 RectTransform을 찾지 못했습니다.");
                }

                transform.localScale = Vector3.one;
           }

            // 상대 체력바 영역 배치
            SetUIRect(mEnemyStatusRoot, new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(0f, -80f), new Vector2(600f, 160f), new Vector2(-mWidth * 0.5f, -80f));
            SetUIRect(mPlayerStatusRoot, new Vector2(1f, 0f), new Vector2(1f, 0f), new Vector2(0f, 300f), new Vector2(600f, 180f), new Vector2(mWidth * 0.5f, -mHeight + 300f));

            // 하단 UI 배치
            SetUIRect(mBottomRoot, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0f, -810f), new Vector2(1440f, 270f), new Vector2(0f, -810f));

            // 싱글 배틀은 Status1만 활성화합니다.
            SetStatusVisible(mEnemyStatus1, true);
            //SetStatusVisible(mEnemyStatus2, false);
            SetStatusVisible(mPlayerStatus1, true);
            //SetStatusVisible(mPlayerStatus2, false);

            // InitializeHPBar(mEnemyHPFill);
            // InitializeHPBar(mPlayerHPFill);

            SetHP(100, 100, 70, 70);

            Log.Info("BattleUI : Single Battle UI 활성화 완료");
        }

        // RectTransform과 일반 Transform의 위치 설정을 통합합니다.
        private void SetUIRect(Transform target, Vector2 anchor, Vector2 pivot, Vector2 anchoredPosition, Vector2 size, Vector2 localPosition)
        {
            if (target == null)
            {
                return;
            }

            RectTransform rect = target as RectTransform;
            RectTransform parentRect = target.parent as RectTransform;

            if (rect != null)
            {
                rect.sizeDelta = size;

                if (parentRect != null)
                {
                    rect.anchorMin          = anchor;
                    rect.anchorMax          = anchor;
                    rect.pivot              = pivot;
                    rect.anchoredPosition   = anchoredPosition;
                }
                else
                {
                    rect.pivot = pivot;
                    rect.localPosition = new Vector3(localPosition.x, localPosition.y, 0f);
                }
            }
            else
            {
                target.localScale = Vector3.one;
            }
        }

        private void SetStatusVisible(Transform status, bool isVisible)
        {
            if (status == null)
            {
                return;
            }

            if (status.gameObject.activeSelf != isVisible)
            {
                status.gameObject.SetActive(isVisible);
            }
        }

        // RectTransform의 위치와 크기를 공통으로 설정합니다.
        private void SetRectTransform(Transform target, Vector2 anchor, Vector2 pivot, Vector2 position, Vector2 size)
        {
            if (target == null)
            {
                return;
            }

            target.localPosition    = position;
            target.localScale       = Vector3.one;
        }

        // 체력바 활성화 여부를 설정합니다.
        private void SetStatusVisible(RectTransform status, bool isVisible)
        {
            if (status == null)
            {
                return;
            }

            // 상태가 다를 때만 변경합니다.
            if (status.gameObject.activeSelf != isVisible)
            {
                status.gameObject.SetActive(isVisible);
            }
        }

        private void InitializeHPBar(Image hpFill)
        {
            if (hpFill == null)
            {
                return;
            }

            hpFill.type = Image.Type.Filled;
            hpFill.fillMethod = Image.FillMethod.Horizontal;
            hpFill.fillOrigin = (int)Image.OriginHorizontal.Left;
        }

        // 상대와 아군의 HP를 설정합니다.
        public void SetHP(int enemyCurrentHP, int enemyMaxHP, int playerCurrentHP, int playerMaxHP)
        {
            //if (mEnemyHPFill != null && enemyMaxHP > 0)
            //{
            //    mEnemyHPFill.fillAmount = Mathf.Clamp01((float)enemyCurrentHP / enemyMaxHP);
            //}

            //if (mPlayerHPFill != null && playerMaxHP > 0)
            //{
            //    mPlayerHPFill.fillAmount = Mathf.Clamp01((float)playerCurrentHP / playerMaxHP);
            //}
        }

        protected internal override void OnClose(bool isShutdown, object userData)
        {
            Log.Info("BattleUI : Close");

            base.OnClose(isShutdown, userData);

        }
    }
}